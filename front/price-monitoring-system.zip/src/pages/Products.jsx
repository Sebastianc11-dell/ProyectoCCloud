"use client"

import { useState, useMemo } from "react"
import { useForm } from "react-hook-form"
import Navbar from "../components/Navbar"
import Footer from "../components/Footer"
import ProductCard from "../components/ProductCard"
import Modal from "../components/Modal"
import { Search, Filter } from "lucide-react"

export default function Products() {
  const { register, watch, reset } = useForm({
    defaultValues: {
      search: "",
      category: "all",
      priceMin: "",
      priceMax: "",
      condition: "all",
      sortBy: "relevance",
    },
  })

  const [showFilters, setShowFilters] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const formValues = watch()

  // Mock product data
  const allProducts = [
    {
      id: 1,
      title: 'Apple MacBook Pro 14" M3 Max',
      price: 1999,
      originalPrice: 2499,
      image: "/apple-macbook-pro-laptop.jpg",
      seller: "TechWorld Store",
      category: "electronics",
      condition: "new",
      rating: 4.8,
      reviews: 245,
    },
    {
      id: 2,
      title: "Sony WH-1000XM5 Wireless Headphones",
      price: 349,
      originalPrice: 399,
      image: "/sony-headphones-audio.jpg",
      seller: "Audio Plus",
      category: "electronics",
      condition: "new",
      rating: 4.7,
      reviews: 892,
    },
    {
      id: 3,
      title: 'Samsung 4K Smart TV 55"',
      price: 649,
      image: "/samsung-tv-4k-television.jpg",
      seller: "Electronics Hub",
      category: "electronics",
      condition: "new",
      rating: 4.6,
      reviews: 156,
    },
    {
      id: 4,
      title: 'iPad Air 11" (2024)',
      price: 799,
      originalPrice: 899,
      image: "/ipad-air-tablet-apple.jpg",
      seller: "Apple Authorized",
      category: "electronics",
      condition: "new",
      rating: 4.9,
      reviews: 523,
    },
    {
      id: 5,
      title: 'Gaming Laptop ASUS ROG 16"',
      price: 1499,
      image: "/asus-rog-gaming-laptop.jpg",
      seller: "GamerZone",
      category: "electronics",
      condition: "new",
      rating: 4.7,
      reviews: 178,
    },
    {
      id: 6,
      title: "Canon EOS R6 Camera",
      price: 2499,
      originalPrice: 2999,
      image: "/canon-eos-dslr-camera-professional.jpg",
      seller: "Photo Equipment Co",
      category: "cameras",
      condition: "new",
      rating: 4.8,
      reviews: 342,
    },
    {
      id: 7,
      title: "DJI Air 3S Drone",
      price: 999,
      image: "/dji-drone-aerial-photography.jpg",
      seller: "Drone Store",
      category: "electronics",
      condition: "new",
      rating: 4.7,
      reviews: 215,
    },
    {
      id: 8,
      title: "Mechanical Gaming Keyboard RGB",
      price: 179,
      originalPrice: 249,
      image: "/mechanical-keyboard-gaming-rgb.jpg",
      seller: "KeyMaster",
      category: "accessories",
      condition: "new",
      rating: 4.6,
      reviews: 87,
    },
    {
      id: 9,
      title: "Logitech MX Master 3S Mouse",
      price: 99,
      image: "/logitech-mouse-wireless.jpg",
      seller: "Peripherals Plus",
      category: "accessories",
      condition: "new",
      rating: 4.8,
      reviews: 421,
    },
    {
      id: 10,
      title: 'Monitor LG UltraWide 38"',
      price: 899,
      originalPrice: 1199,
      image: "/lg-ultrawide-monitor-gaming.jpg",
      seller: "Display World",
      category: "electronics",
      condition: "new",
      rating: 4.7,
      reviews: 134,
    },
    {
      id: 11,
      title: "USB-C Hub 7-in-1",
      price: 49,
      image: "/usb-hub-adapter-multiport.jpg",
      seller: "Accessory Store",
      category: "accessories",
      condition: "new",
      rating: 4.5,
      reviews: 203,
    },
    {
      id: 12,
      title: "Portable SSD 2TB Samsung T7",
      price: 189,
      originalPrice: 249,
      image: "/samsung-ssd-portable-storage.jpg",
      seller: "Storage Solutions",
      category: "storage",
      condition: "new",
      rating: 4.8,
      reviews: 567,
    },
  ]

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let result = allProducts

    // Search filter
    if (formValues.search) {
      result = result.filter((p) => p.title.toLowerCase().includes(formValues.search.toLowerCase()))
    }

    // Category filter
    if (formValues.category !== "all") {
      result = result.filter((p) => p.category === formValues.category)
    }

    // Price filter
    if (formValues.priceMin) {
      result = result.filter((p) => p.price >= Number.parseInt(formValues.priceMin))
    }
    if (formValues.priceMax) {
      result = result.filter((p) => p.price <= Number.parseInt(formValues.priceMax))
    }

    // Condition filter
    if (formValues.condition !== "all") {
      result = result.filter((p) => p.condition === formValues.condition)
    }

    // Sort
    switch (formValues.sortBy) {
      case "price-asc":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-desc":
        result.sort((a, b) => b.price - a.price)
        break
      case "rating":
        result.sort((a, b) => b.rating - a.rating)
        break
      default:
        break
    }

    return result
  }, [formValues])

  const handleAddToTracking = (product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  const handleConfirmTracking = () => {
    // TODO: Call API to add to tracking
    console.log("Added to tracking:", selectedProduct)
    setIsModalOpen(false)
    setSelectedProduct(null)
  }

  return (
    <div className="container-app">
      <Navbar />

      <main className="flex-1 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">Find Products</h1>
            <p className="text-foreground-muted">Search and discover products to monitor</p>
          </div>

          {/* Search Bar */}
          <div className="mb-8">
            <div className="relative">
              <Search size={20} className="absolute left-4 top-3 text-foreground-muted" />
              <input
                type="text"
                {...register("search")}
                placeholder="Search products..."
                className="input-base pl-12 py-3 text-base"
              />
            </div>
          </div>

          {/* Filters and Products */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Filters Sidebar - Desktop */}
            <div className="hidden lg:block">
              <FilterPanel register={register} formValues={formValues} />
            </div>

            {/* Products Section */}
            <div className="lg:col-span-3">
              {/* Mobile Filter Toggle */}
              <div className="lg:hidden mb-6">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2 btn-secondary w-full justify-center"
                >
                  <Filter size={20} />
                  {showFilters ? "Hide Filters" : "Show Filters"}
                </button>
              </div>

              {/* Mobile Filter Panel */}
              {showFilters && (
                <div className="lg:hidden mb-6 card-base">
                  <FilterPanel register={register} formValues={formValues} />
                </div>
              )}

              {/* Sort Bar */}
              <div className="flex justify-between items-center mb-6">
                <p className="text-foreground-muted">Showing {filteredProducts.length} products</p>
                <select {...register("sortBy")} className="input-base py-2 text-sm max-w-xs">
                  <option value="relevance">Relevance</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
              </div>

              {/* Products Grid */}
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} onAddToTracking={handleAddToTracking} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-foreground-muted mb-4">No products found</p>
                  <button onClick={() => reset()} className="btn-primary">
                    Clear Filters
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Add to Tracking Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Add to Tracking">
        {selectedProduct && (
          <div className="space-y-4">
            <div className="flex gap-4">
              <img
                src={selectedProduct.image || "/placeholder.svg"}
                alt={selectedProduct.title}
                className="w-24 h-24 rounded-lg object-cover"
              />
              <div>
                <h3 className="font-semibold text-foreground mb-2">{selectedProduct.title}</h3>
                <p className="text-2xl font-bold text-primary">${selectedProduct.price}</p>
              </div>
            </div>
            <div className="p-4 rounded-lg bg-primary bg-opacity-10 border border-primary">
              <p className="text-sm text-foreground">
                We'll monitor this product and notify you when the price changes or when it's back in stock.
              </p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setIsModalOpen(false)} className="btn-secondary flex-1">
                Cancel
              </button>
              <button onClick={handleConfirmTracking} className="btn-primary flex-1">
                Add to Tracking
              </button>
            </div>
          </div>
        )}
      </Modal>

      <Footer />
    </div>
  )
}

// Filter Panel Component
function FilterPanel({ register, formValues }) {
  const [expandedCategory, setExpandedCategory] = useState(null)

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "electronics", label: "Electronics" },
    { value: "cameras", label: "Cameras" },
    { value: "accessories", label: "Accessories" },
    { value: "storage", label: "Storage" },
  ]

  const conditions = [
    { value: "all", label: "Any Condition" },
    { value: "new", label: "New" },
    { value: "refurbished", label: "Refurbished" },
    { value: "used", label: "Used" },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold text-foreground mb-4 flex items-center gap-2">
          <Filter size={18} />
          Filters
        </h3>
      </div>

      {/* Category Filter */}
      <div>
        <button
          onClick={() => setExpandedCategory(expandedCategory === "category" ? null : "category")}
          className="w-full text-left font-semibold text-foreground mb-3 flex items-center justify-between"
        >
          Category
          <span className={`transform transition ${expandedCategory === "category" ? "rotate-180" : ""}`}>▼</span>
        </button>
        {expandedCategory === "category" && (
          <div className="space-y-2">
            {categories.map((cat) => (
              <label key={cat.value} className="flex items-center gap-3 cursor-pointer">
                <input type="radio" value={cat.value} {...register("category")} className="w-4 h-4 rounded" />
                <span className="text-foreground-muted text-sm">{cat.label}</span>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Price Filter */}
      <div>
        <button
          onClick={() => setExpandedCategory(expandedCategory === "price" ? null : "price")}
          className="w-full text-left font-semibold text-foreground mb-3 flex items-center justify-between"
        >
          Price Range
          <span className={`transform transition ${expandedCategory === "price" ? "rotate-180" : ""}`}>▼</span>
        </button>
        {expandedCategory === "price" && (
          <div className="space-y-3">
            <div>
              <label className="text-sm text-foreground-muted mb-1 block">Min Price</label>
              <input type="number" {...register("priceMin")} placeholder="$0" className="input-base text-sm" />
            </div>
            <div>
              <label className="text-sm text-foreground-muted mb-1 block">Max Price</label>
              <input type="number" {...register("priceMax")} placeholder="$5000" className="input-base text-sm" />
            </div>
          </div>
        )}
      </div>

      {/* Condition Filter */}
      <div>
        <button
          onClick={() => setExpandedCategory(expandedCategory === "condition" ? null : "condition")}
          className="w-full text-left font-semibold text-foreground mb-3 flex items-center justify-between"
        >
          Condition
          <span className={`transform transition ${expandedCategory === "condition" ? "rotate-180" : ""}`}>▼</span>
        </button>
        {expandedCategory === "condition" && (
          <div className="space-y-2">
            {conditions.map((cond) => (
              <label key={cond.value} className="flex items-center gap-3 cursor-pointer">
                <input type="radio" value={cond.value} {...register("condition")} className="w-4 h-4 rounded" />
                <span className="text-foreground-muted text-sm">{cond.label}</span>
              </label>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
